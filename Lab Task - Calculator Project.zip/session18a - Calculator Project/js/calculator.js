// Your task is to add interactivity to the Calculator UI given. 
// User Story
// The user will enter numeric values in the input elements of type number.
// To have the result, the user would click on any of the five buttons *, -, +, /, %
// Based on the button clicked, your app should perform the expected calculation and display the answer in the input element of type text.
// Best of luck!

